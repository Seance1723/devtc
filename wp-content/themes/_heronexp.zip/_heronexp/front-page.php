<?php get_header(); ?>

<main id="home">
    <section class="hero">
        <h1><?php bloginfo('name'); ?></h1>
        <p><?php bloginfo('description'); ?></p>
    </section>
</main>

<?php get_footer(); ?>
