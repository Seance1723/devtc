<?php get_header(); ?>

<main id="site-content">
    <section>
        <h1><?php esc_html_e('Welcome to HERON!', 'heron'); ?></h1>
        <p><?php esc_html_e('This is the fallback template.', 'heron'); ?></p>
    </section>
</main>

<?php get_footer(); ?>
