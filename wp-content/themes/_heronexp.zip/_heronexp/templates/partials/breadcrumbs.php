<?php
if (!defined('ABSPATH')) {
    exit;
}

if (function_exists('heron_breadcrumbs')) {
    heron_breadcrumbs();
}
